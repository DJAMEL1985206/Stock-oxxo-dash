# 🚀 Guide de Démarrage Rapide - Stock Dashboard Android

## Option 1 : Compilation avec Android Studio (La plus simple)

### Étape 1 : Installer Android Studio
1. Téléchargez Android Studio depuis : https://developer.android.com/studio
2. Installez-le sur votre ordinateur
3. Lancez Android Studio et suivez l'assistant de configuration

### Étape 2 : Ouvrir le Projet
1. Lancez Android Studio
2. Cliquez sur "Open" ou "Open an Existing Project"
3. Naviguez vers le dossier `stock-app-android`
4. Sélectionnez le dossier et cliquez sur "OK"

### Étape 3 : Attendre la Synchronisation
- Android Studio va automatiquement :
  - Télécharger Gradle
  - Télécharger les dépendances
  - Synchroniser le projet
- Cela peut prendre quelques minutes la première fois

### Étape 4 : Compiler l'APK
1. Dans le menu, cliquez sur : **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. Attendez la fin de la compilation (quelques minutes)
3. Une notification apparaîtra avec "APK(s) generated successfully"
4. Cliquez sur "locate" pour trouver l'APK

### Étape 5 : Installer l'APK sur votre Téléphone
1. L'APK se trouve dans : `app/build/outputs/apk/debug/app-debug.apk`
2. **Méthode A - Via Cable USB :**
   - Activez "Débogage USB" sur votre téléphone Android
   - Connectez votre téléphone à l'ordinateur
   - Cliquez sur le bouton "Run" (▶) dans Android Studio
   
3. **Méthode B - Transfert Manuel :**
   - Copiez le fichier `app-debug.apk` sur votre téléphone
   - Sur votre téléphone, allez dans Paramètres → Sécurité → Autoriser les sources inconnues
   - Ouvrez le gestionnaire de fichiers et tapez sur `app-debug.apk`
   - Suivez les instructions d'installation

---

## Option 2 : Compilation en Ligne de Commande

### Prérequis
- Java JDK 8 ou supérieur installé
- Android SDK installé
- Variable d'environnement `ANDROID_HOME` configurée

### Étapes

#### Sur Linux/Mac :
```bash
cd stock-app-android
./gradlew assembleDebug
```

#### Sur Windows :
```cmd
cd stock-app-android
gradlew.bat assembleDebug
```

L'APK sera généré dans : `app/build/outputs/apk/debug/app-debug.apk`

---

## Option 3 : Build en Ligne (Sans Installation)

### GitHub Actions (Gratuit)

1. Créez un compte GitHub si vous n'en avez pas
2. Créez un nouveau repository
3. Uploadez tous les fichiers du dossier `stock-app-android`
4. Créez un fichier `.github/workflows/android.yml` avec :

```yaml
name: Android Build

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up JDK 11
      uses: actions/setup-java@v3
      with:
        java-version: '11'
        distribution: 'temurin'
    - name: Grant execute permission for gradlew
      run: chmod +x gradlew
    - name: Build with Gradle
      run: ./gradlew assembleDebug
    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: app-debug
        path: app/build/outputs/apk/debug/app-debug.apk
```

5. Poussez le code et GitHub compilera automatiquement l'APK
6. Téléchargez l'APK depuis les "Artifacts" de la build

---

## ⚠️ Problèmes Courants et Solutions

### "SDK location not found"
**Solution :** Créez un fichier `local.properties` à la racine avec :
```
sdk.dir=/path/to/your/Android/Sdk
```

### "Gradle sync failed"
**Solution :** 
1. File → Invalidate Caches / Restart
2. Redémarrez Android Studio

### "Unable to find tools.jar"
**Solution :** Assurez-vous d'avoir installé le JDK (pas juste le JRE)

### L'APK ne s'installe pas sur le téléphone
**Solution :** 
1. Vérifiez que "Sources inconnues" est activé
2. Si vous avez une ancienne version installée, désinstallez-la d'abord

---

## 📱 Test de l'Application

Une fois installée :
1. Lancez l'application "Stock Dashboard" depuis votre téléphone
2. Attendez quelques secondes que la page se charge
3. Vous devriez voir le dashboard de gestion de stock
4. Testez l'import d'un fichier Excel pour vérifier que tout fonctionne

---

## 🎯 Prochaines Étapes

Après l'installation réussie :
- Importez vos données de stock via Excel
- Configurez vos filtres préférés
- Explorez toutes les fonctionnalités (graphiques, prévisions, étiquettes)
- Exportez régulièrement vos données pour sauvegarder

---

## 💡 Besoin d'Aide ?

Si vous rencontrez des problèmes :
1. Vérifiez que vous avez bien suivi toutes les étapes
2. Consultez la documentation Android officielle
3. Vérifiez les logs d'erreur dans Android Studio (onglet "Build")

**Bon développement ! 🚀**
