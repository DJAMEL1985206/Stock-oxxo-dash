# Stock Dashboard - Application Android

## 📱 Application de Gestion de Stock et Disponibilité

Cette application Android intègre le dashboard de gestion de stock complet avec toutes ses fonctionnalités.

## 🚀 Méthodes de Compilation

### Méthode 1 : Android Studio (Recommandée)

1. Ouvrez Android Studio
2. Sélectionnez "Open an Existing Project"
3. Naviguez vers ce dossier et sélectionnez-le
4. Attendez que Gradle synchronise le projet
5. Cliquez sur "Build" → "Build Bundle(s) / APK(s)" → "Build APK(s)"
6. L'APK sera généré dans `app/build/outputs/apk/debug/`

### Méthode 2 : Ligne de Commande (Linux/Mac/Windows)

```bash
# Assurez-vous d'avoir installé Android SDK et définit ANDROID_HOME
cd stock-app-android
./gradlew assembleDebug

# L'APK sera dans app/build/outputs/apk/debug/app-debug.apk
```

### Méthode 3 : Compilation en Ligne

Utilisez un service de build en ligne comme :
- **Appetize.io**
- **App Center** (Microsoft)
- **GitHub Actions** avec Android CI/CD

## 📦 Installation de l'APK

Une fois l'APK compilé :

1. **Sur votre téléphone Android :**
   - Activez "Sources inconnues" dans Paramètres → Sécurité
   - Transférez l'APK sur votre téléphone
   - Tapez sur le fichier APK pour l'installer

2. **Via ADB (Android Debug Bridge) :**
   ```bash
   adb install app-debug.apk
   ```

## ✨ Fonctionnalités de l'Application

- ✅ Dashboard complet de gestion de stock
- ✅ Import/Export Excel
- ✅ Graphiques interactifs avec Chart.js
- ✅ Filtres avancés multiples
- ✅ Calcul automatique d'autonomie
- ✅ Analyse ABC
- ✅ Prévisions de stock
- ✅ Impression d'étiquettes avec QR codes
- ✅ Interface responsive optimisée mobile
- ✅ Support hors-ligne (données stockées localement)

## 🔧 Configuration Technique

- **Langage :** Java
- **SDK Minimum :** Android 5.0 (API 21)
- **SDK Cible :** Android 13 (API 33)
- **WebView :** Activé avec JavaScript
- **Permissions :** Internet (pour les CDN), Stockage local

## 📝 Structure du Projet

```
stock-app-android/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── assets/
│   │       │   └── index.html          # Dashboard HTML
│   │       ├── java/
│   │       │   └── com/stockapp/
│   │       │       └── MainActivity.java
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml
│   │       │   └── values/
│   │       │       ├── strings.xml
│   │       │       └── colors.xml
│   │       └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── README.md
```

## 🌐 CDN et Dépendances

L'application charge automatiquement depuis les CDN :
- Chart.js 4.4.1
- SheetJS (XLSX) 0.18.5
- ExcelJS 4.3.0
- QRCode.js 1.0.0
- Google Fonts

**Note :** Une connexion Internet est requise au premier lancement pour charger ces bibliothèques.

## 🎨 Personnalisation

Pour modifier le thème ou les couleurs :
- Éditez `app/src/main/res/values/colors.xml`
- Modifiez les variables CSS dans `index.html`

## ⚠️ Notes Importantes

1. **Première Utilisation :** L'application nécessite une connexion Internet pour charger les CDN
2. **Stockage :** Les données sont stockées dans le LocalStorage du WebView
3. **Sauvegarde :** Exportez régulièrement vos données en Excel
4. **Performance :** Optimisé pour tablettes et smartphones Android modernes

## 🐛 Dépannage

### L'application ne démarre pas
- Vérifiez que vous avez au minimum Android 5.0
- Vérifiez les permissions Internet dans les paramètres

### Les graphiques ne s'affichent pas
- Assurez-vous d'avoir une connexion Internet active
- Redémarrez l'application

### Erreur lors de l'import Excel
- Vérifiez le format du fichier Excel (.xlsx)
- Assurez-vous que les colonnes requises sont présentes

## 📄 Licence

Application créée pour la gestion interne de stock.

## 🔄 Mises à Jour

Version 1.0 - Mars 2026
- Version initiale avec toutes les fonctionnalités du dashboard

## 💡 Support

Pour toute question ou problème, contactez l'équipe de développement.

---

**Développé avec ❤️ pour une gestion de stock efficace**
